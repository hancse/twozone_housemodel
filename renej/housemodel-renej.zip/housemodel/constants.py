KEY_TIME = 'time'

KEY_T_AIR = 'T_air'
KEY_T_WALL = 'T_wall'
KEY_T_RADIATOR = 'T_radiator'
KEY_T_OUTDOOR = 'T_outdoor'

KEY_SETPOINT = 'SP'

KEY_Q_SOLAR = 'Q_solar'
KEY_Q_INTERNAL = 'Q_internal'

KEY_CLOUD = "cloud"  # different name
KEY_SOLAR = "solar"  # 'solar radiation'?
